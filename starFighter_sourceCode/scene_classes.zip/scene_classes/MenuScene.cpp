#include"MenuScene.h"

MenuScene::MenuScene()
{
	CreateAssets();
}
	
MenuScene::~MenuScene()
{
}

void MenuScene::Begin()
{
	GameObject* temp;
	float position[3];
	float scale[3];
	float amb[4];
	float dif[4];
	float spec[4];

	temp = new GameObject;
	position[0] = -0.577f, position[1] = 0.577f, position[2] = -0.577f;
	amb[0] = 0.6f, amb[1] = 0.6f, amb[2] = 0.6f, amb[3] = 1.0f;
	dif[0] = 1.0f, dif[1] = 1.0f, dif[2] = 1.0f, dif[3] = 1.0f;
	spec[0] = 1.0f, spec[1] = 1.0f, spec[2] = 1.0f, spec[3] = 1.0f;
	temp->SetName("light");
	temp->SetType(noUpdate);
	temp->SetScale(scale);
	temp->SetPosition(position);
	temp->SetAmbient(amb);
	temp->SetDiffuse(dif);
	temp->SetSpecular(spec);
	temp->SetIsAwake(false);
	Add(temp);

	temp = new GameObject;
	scale[0] = 0, scale [1] = 0, scale[2] = 0;
	position[0] = 0.0, position[1] = 0.0, position[2] = 2100.0;
	amb[0] = 0.0f, amb[1] = 1.0f, amb[2] = 0.0f, amb[3] = 0.0f;
	temp->SetName("camera");
	temp->SetType(noUpdate);
	temp->SetScale(scale);
	temp->SetPosition(position);
	temp->SetAmbient(amb);
	temp->SetIsAwake(false);
	Add(temp);

	temp = new GameObject;
	temp = ReturnAsset("effects");
	Add(temp);

	temp = new GameObject;
	temp = ReturnAsset("opening");
	dif[0] = 0.3f, dif[1] = 0.1f, dif[2] = 1.0f, dif[3] = 1.0f;
	temp->SetDiffuse(dif);
	Add(temp);
	SetMessages(L"Made Possible By", temp->GetName());

	temp = new GameObject;
	temp = ReturnAsset("logo");
	Add(temp);
	
	temp = new GameObject;
	temp = ReturnAsset("3dsMaxBanner");
	Add(temp);
	
	temp = new GameObject;
	temp = ReturnAsset("3dsMaxLogo");
	Add(temp);
	
	temp = new GameObject;
	temp = ReturnAsset("gimpLogo");
	Add(temp);

	temp = new GameObject;
	temp = ReturnAsset("ParentalAdvisory");
	Add(temp);

	temp = new GameObject;
	temp = ReturnAsset("RatingExplicit");
	Add(temp);
	
	temp = new GameObject;
	temp = ReturnAsset("DiscoveryHit");
	temp->SetCanSleep(true);
	Add(temp);

	temp = new GameObject;
	temp = ReturnAsset("BlackVortex");
	temp->SetCanSleep(false);
	Add(temp);
}

void MenuScene::CreateAssets()
{
	GameObject* sceneAsset;
	float position[3];
	float scale[3];
	float dif[4];
	scale[0] = 1.0f, scale[1] = 1.0f, scale[2] = 1.0f;
	dif[0] = 1.0f, dif [1] = 1.0f, dif[2] = 1.0f, dif[3] = 1.0f;

	sceneAsset = new GameObject;
	position[0] = 400, position[1] = 300, position[2] = 0;
	sceneAsset->SetFileName(L"menubackground.jpg");
	sceneAsset->SetName("menuBack");
	sceneAsset->SetType(noUpdate);
	sceneAsset->SetAssetType(spriteType);
	sceneAsset->SetScale(scale);
	sceneAsset->SetPosition(position);
	sceneAsset->SetDiffuse(dif);
	sceneAsset->SetIsAwake(true);
	sceneAsset->CalcTransformation();
	SetSceneAssets(sceneAsset);

	sceneAsset = new GameObject;
	position[0] = 300, position[1] = 300, position[2] = 0;
	sceneAsset->SetFileName(L"newgameh.jpg");
	sceneAsset->SetName("newGameH");
	sceneAsset->SetType(noUpdate);
	sceneAsset->SetAssetType(spriteType);
	sceneAsset->SetScale(scale);
	sceneAsset->SetPosition(position);
	sceneAsset->SetDiffuse(dif);
	sceneAsset->SetIsAwake(true);
	sceneAsset->CalcTransformation();
	SetSceneAssets(sceneAsset);

	sceneAsset = new GameObject;
	sceneAsset->SetFileName(L"newgame.jpg");
	sceneAsset->SetName("newGame");
	sceneAsset->SetType(noUpdate);
	sceneAsset->SetAssetType(spriteType);
	sceneAsset->SetScale(scale);
	sceneAsset->SetPosition(position);
	sceneAsset->SetDiffuse(dif);
	sceneAsset->SetIsAwake(true);
	sceneAsset->CalcTransformation();
	SetSceneAssets(sceneAsset);
	
	sceneAsset = new GameObject;
	position[0] = 400, position[1] = 500, position[2] = 0;
	sceneAsset->SetFileName(L"exit.jpg");
	sceneAsset->SetName("exit");
	sceneAsset->SetType(noUpdate);
	sceneAsset->SetAssetType(spriteType);
	sceneAsset->SetScale(scale);
	sceneAsset->SetPosition(position);
	sceneAsset->SetDiffuse(dif);
	sceneAsset->SetIsAwake(true);
	sceneAsset->CalcTransformation();
	SetSceneAssets(sceneAsset);

	sceneAsset = new GameObject;
	sceneAsset->SetFileName(L"exith.jpg");
	sceneAsset->SetName("exitH");
	sceneAsset->SetType(noUpdate);
	sceneAsset->SetAssetType(spriteType);
	sceneAsset->SetScale(scale);
	sceneAsset->SetPosition(position);
	sceneAsset->SetDiffuse(dif);
	sceneAsset->SetIsAwake(true);
	sceneAsset->CalcTransformation();
	SetSceneAssets(sceneAsset);

	sceneAsset = new GameObject;
	sceneAsset->SetFileName(L"DirLightTex.fx");
	sceneAsset->SetName("effects");
	sceneAsset->SetType(noUpdate);
	sceneAsset->SetAssetType(effectsType);
	sceneAsset->SetScale(scale);
	sceneAsset->SetPosition(position);
	sceneAsset->SetDiffuse(dif);
	sceneAsset->SetIsAwake(false);
	SetSceneAssets(sceneAsset);

	sceneAsset = new GameObject;
	position[0] = 400, position[1] = 500, position[2] = 0;
	sceneAsset->SetFileName(L"3dsMax_banner.png");
	sceneAsset->SetName("3dsMaxBanner");
	sceneAsset->SetType(noUpdate);
	sceneAsset->SetAssetType(spriteType);
	sceneAsset->SetScale(scale);
	sceneAsset->SetPosition(position);
	sceneAsset->SetDiffuse(dif);
	sceneAsset->SetIsAwake(true);
	sceneAsset->CalcTransformation();
	SetSceneAssets(sceneAsset);

	sceneAsset = new GameObject;
	position[0] = 400, position[1] = 500, position[2] = 0;
	sceneAsset->SetFileName(L"3dsMax_logo.png");
	sceneAsset->SetName("3dsMaxLogo");
	sceneAsset->SetType(noUpdate);
	sceneAsset->SetAssetType(spriteType);
	sceneAsset->SetScale(scale);
	sceneAsset->SetPosition(position);
	sceneAsset->SetDiffuse(dif);
	sceneAsset->SetIsAwake(true);
	sceneAsset->CalcTransformation();
	SetSceneAssets(sceneAsset);

	sceneAsset = new GameObject;
	position[0] = 64, position[1] = 64, position[2] = 0;
	sceneAsset->SetFileName(L"logo.png");
	sceneAsset->SetName("logo");
	sceneAsset->SetType(noUpdate);
	sceneAsset->SetAssetType(spriteType);
	sceneAsset->SetScale(scale);
	sceneAsset->SetPosition(position);
	sceneAsset->SetDiffuse(dif);
	sceneAsset->SetIsAwake(true);
	sceneAsset->CalcTransformation();
	SetSceneAssets(sceneAsset);

	sceneAsset = new GameObject;
	position[0] = 400, position[1] = 500, position[2] = 0;
	sceneAsset->SetFileName(L"gimp-logo.png");
	sceneAsset->SetName("gimpLogo");
	sceneAsset->SetType(noUpdate);
	sceneAsset->SetAssetType(spriteType);
	sceneAsset->SetScale(scale);
	sceneAsset->SetPosition(position);
	sceneAsset->SetDiffuse(dif);
	sceneAsset->SetIsAwake(true);
	sceneAsset->CalcTransformation();
	SetSceneAssets(sceneAsset);

	sceneAsset = new GameObject;
	position[0] = 400, position[1] = 500, position[2] = 0;
	sceneAsset->SetFileName(L"ParentalAdvisory.png");
	sceneAsset->SetName("ParentalAdvisory");
	sceneAsset->SetType(noUpdate);
	sceneAsset->SetAssetType(spriteType);
	sceneAsset->SetScale(scale);
	sceneAsset->SetPosition(position);
	sceneAsset->SetDiffuse(dif);
	sceneAsset->SetIsAwake(true);
	sceneAsset->CalcTransformation();
	SetSceneAssets(sceneAsset);

	sceneAsset = new GameObject;
	position[0] = 400, position[1] = 500, position[2] = 0;
	sceneAsset->SetFileName(L"RatingExplicit.png");
	sceneAsset->SetName("RatingExplicit");
	sceneAsset->SetType(noUpdate);
	sceneAsset->SetAssetType(spriteType);
	sceneAsset->SetScale(scale);
	sceneAsset->SetPosition(position);
	sceneAsset->SetDiffuse(dif);
	sceneAsset->SetIsAwake(true);
	sceneAsset->CalcTransformation();
	SetSceneAssets(sceneAsset);

	sceneAsset = new GameObject;
	position[0] = 24.0, position[1] = 12.0;
	sceneAsset->SetName("opening");
	sceneAsset->SetAssetType(fontType);
	sceneAsset->SetFileName(L"Times New Roman");
	sceneAsset->SetType(noUpdate);
	sceneAsset->SetPosition(position);
	sceneAsset->SetCanSleep(false);
	SetSceneAssets(sceneAsset);

	sceneAsset = new GameObject;
	sceneAsset->SetName("BlackVortex");
	sceneAsset->SetAssetType(audioType);
	sceneAsset->SetSound("Black Vortex.mp3");
	sceneAsset->SetType(noUpdate);
	sceneAsset->SetCanSleep(false);
	SetSceneAssets(sceneAsset);

	sceneAsset = new GameObject;
	sceneAsset->SetName("DiscoveryHit");
	sceneAsset->SetAssetType(audioType);
	sceneAsset->SetSound("Discovery Hit.mp3");
	sceneAsset->SetType(noUpdate);
	sceneAsset->SetCanSleep(false);
	SetSceneAssets(sceneAsset);
}

void MenuScene::Highlight()
{
	if(GetInstance("newGame"))
	{
		Remove(GetInstance("newGame"));
		Add(ReturnAsset("newGameH"));
		Remove(GetInstance("exitH"));
		Add(ReturnAsset("exit"));
	}
	else
	{
		Remove(GetInstance("newGameH"));
		Add(ReturnAsset("newGame"));
		Remove(GetInstance("exit"));
		Add(ReturnAsset("exitH"));
	}
}