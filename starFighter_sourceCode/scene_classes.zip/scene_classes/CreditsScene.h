#pragma once
#include "Scene.h"

class CreditsScene : public Scene
{
public:
	CreditsScene();
	~CreditsScene();

	void Begin();
	void CreateAssets();
};