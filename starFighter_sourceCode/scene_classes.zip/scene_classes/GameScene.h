#pragma once
#include "Scene.h"

class GameScene : public Scene
{
private:
	void CreateAssets();
public:
	GameScene ();
	~GameScene ();
	void Begin ();
};