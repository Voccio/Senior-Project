#pragma once
#include "Scene.h"

class MenuScene : public Scene
{
private:
	void CreateAssets();
public:
	MenuScene();
	~MenuScene();
	void Begin();
	void Highlight();
};