#pragma once
#include "Clock.h"
#include "DX.h"
#include "Screen.h"
#include "SpriteManager.h"
#include "Audio.h"
#include"Mesh.h"
#include"Effects.h"
#include"Font.h"
#include"Light.h"
#include"Video.h"
#include"GameLogic.h"
#include<map>
using namespace std;




class Engine
{
private:
	// the current scene
	Scene* currentScene;
	// scene to switch to at end of frame
	Scene* toScene;
	//engine cores
	Clock* clock;
	AudioClass* audio;
	DXClass* dx;
	EffectsClass* effects;
	LightClass* light;
	MeshClass* mesh;
	ScreenClass* screen;
	SpriteClass* spriteManager;
	VideoClass* video;
	FontClass* write;
	GameLogicClass* logic;

	// called when engine first starts
	void Startup(HINSTANCE hInstance);
	// updates scene every frame
	void Update(float dt);
	// renders frame ever frame
	void Render();
	// called when engine ends
	void Shutdown();
	
	void LoadSceneAssets(map<string, GameObject*> sceneAssets);
	void CreateCamera(GameObject* camObject);
	void CreateLight(GameObject* lightObject);
public:
	Engine ();
	~Engine ();
	// game loop
	void Run (HINSTANCE hInstance);
	// getters/setters
	void SetCurrentScene (Scene* scene);
	Scene* GetCurrentScene ();
};