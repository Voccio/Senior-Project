#include <Windows.h>
#include <iostream>
#include "Engine.h"

Engine::Engine ()
{
	currentScene = nullptr;
	toScene = nullptr;
	clock = new Clock();
	screen = new ScreenClass();
	dx = new DXClass();
	spriteManager = new SpriteClass();
	audio = new AudioClass();
	light = new LightClass();
	mesh = new MeshClass();
	video = new VideoClass();
	effects = new EffectsClass();
	logic = new GameLogicClass();
	write = new FontClass();
}

Engine::~Engine ()
{

}

void Engine::Startup (HINSTANCE hInstance)
{
	screen->InitWindow(hInstance);
	dx->InitDX(screen->ReturnGameWnd(), screen->ReturnGameWindowed());
	audio->InitAudio(screen->ReturnGameWnd());
	spriteManager->CreateSprite(dx->ReturnDirectDevice());
	mesh->InitMeshClass(dx->ReturnDirectDevice());
	logic->Startup(screen->ReturnGameWnd(), hInstance);
}

void Engine::Shutdown ()
{
	screen->Shutdown();
	dx->Shutdown();
	audio->Shutdown();
	spriteManager->Shutdown();
	logic->Shutdown();
	write->Shutdown();
}

void Engine::Run (HINSTANCE hInstance)
{
	Startup(hInstance);
	
	// msg structure to catch window messages
	MSG msg; 
	ZeroMemory(&msg, sizeof(msg));

	// game loop
	while(msg.message != WM_QUIT)
	{
		if(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		{
			// calculate elapsed time
			clock->UpdateElapsed();

			// update components
			clock->StartUpdate();
			Update(clock->Elapsed());
			clock->EndUpdate();

			// render renderable components
			clock->StartRender();
			Render();
			clock->EndRender();
		}
		if(logic->GetScene()->ReturnGameState() == 3)
				msg.message = WM_QUIT;
	}
	Shutdown();
}

void Engine::SetCurrentScene (Scene* scene)
{
	toScene = scene;
}

Scene* Engine::GetCurrentScene ()
{
	return currentScene;
}

void Engine::Update(float dt)
{
	if(logic->GetScene() != currentScene)
		SetCurrentScene(logic->GetScene());
	if (toScene)
	{
		if (currentScene) currentScene->End();
		currentScene = toScene;
		LoadSceneAssets(currentScene->LoadAssets());
		currentScene->Begin();
		if(currentScene->GetInstance("light"))
			CreateLight(currentScene->GetInstance("light"));
		toScene = nullptr;
	}
	if(!currentScene->ReturnVideoPlay())
	{
		if(currentScene != nullptr)
			logic->Update(currentScene, dt);
		currentScene->Update();
	}
	else
		video->VideoCompleted(screen->ReturnGameWnd());
}

void Engine::Render ()
{
	if(!currentScene->ReturnVideoPlay())
	{
		dx->StartRender(screen->ReturnGameWnd());
		effects->SetLight(currentScene->GetInstance("effects")->GetFileName(), light->ReturnLight("light"));
		effects->SetTech(currentScene->GetInstance("effects")->GetFileName());
		effects->SetCamPos(currentScene->GetInstance("effects")->GetFileName(), logic->GetCamera()->ReturnPosition());
		UINT numPasses = 0;
		effects->Begin(currentScene->GetInstance("effects")->GetFileName(), numPasses);
		spriteManager->StartRender();
		std::list<GameObject*> renderList;
		renderList = currentScene->ReturnGameRenders();
		for (std::list<GameObject*>::iterator i = renderList.begin(); i != renderList.end(); ++i)
		{
			if((*i)->ReturnAssetType() == meshType)
			{
				effects->SetFX(currentScene->GetInstance("effects")->GetFileName(), logic->GetCamera()->ReturnViewProj(), (*i)->GetTransformation());
				for(UINT j = 0; j < mesh->ReturnNumMtrls((*i)->GetFileName()); j++)
				{
					effects->BeginPass(currentScene->GetInstance("effects")->GetFileName(), j);
					effects->SetFXMaterial(currentScene->GetInstance("effects")->GetFileName(),
						mesh->ReturnMaterial((*i)->GetFileName(), j));
					if(mesh->ReturnTexture((*i)->GetFileName(), j) != 0)
					{
						effects->SetFXTexture(currentScene->GetInstance("effects")->GetFileName(),
							mesh->ReturnTexture((*i)->GetFileName(), j));
					}
					else
					{
						effects->SetFXTexture(currentScene->GetInstance("effects")->GetFileName(),
							spriteManager->ReturnSpriteTex(currentScene->GetInstance("defaultTex")->GetFileName()));
					}
					mesh->Render((*i)->GetFileName(), dx->ReturnDirectDevice(), j);
					effects->EndPass(currentScene->GetInstance("effects")->GetFileName());
				}
			}
			else if((*i)->ReturnAssetType() == spriteType)
			{
				RECT rect;
				GetWindowRect(screen->ReturnGameWnd(), &rect);
				spriteManager->Render((*i)->GetFileName(), (*i)->GetTransformation(), (*i)->GetDiffuse(), rect);
			}
			else if((*i)->ReturnAssetType() == fontType)
			{
				RECT rect;
				GetClientRect(screen->ReturnGameWnd(), &rect);
				write->Render((*i)->GetName(), currentScene->GetMessages((*i)->GetName()), rect, (*i)->GetDiffuse());
			}
			else if((*i)->ReturnAssetType() == audioType)
			{
				//if((*i)->GetCanSleep())
					//audio->PlaySoundW((*i)->GetSoundName());
			}
		}
		spriteManager->EndRender();
		renderList.clear();
		effects->End(currentScene->GetInstance("effects")->GetFileName());
		dx->EndRender();
	}
}

void Engine::LoadSceneAssets(map<string, GameObject*> sceneAssets)
{
	  for(map<string, GameObject*>::iterator i = sceneAssets.begin(); i != sceneAssets.end(); i++)
	 {
		 switch(i->second->ReturnAssetType())
		 {
		 case(0):
			 audio->LoadSound(i->second->GetSoundName());
			 break;
		 case(1):
			 effects->LoadEffects(i->second->GetFileName(), dx->ReturnDirectDevice());
			 effects->Reset(i->second->GetFileName());
			 break;
		 case(2):
			 write->CreateFont(dx->ReturnDirectDevice(),i->second->GetPosition()[0], i->second->GetPosition()[1], 
				 i->second->GetCanSleep(), i->second->GetName(), i->second->GetFileName());
			 break;
		 case(3):
			 mesh->LoadXFile(i->second->GetFileName(), dx->ReturnDirectDevice());
			 i->second->SetAABB(mesh->ComputeBoundingBox(i->second->GetFileName()));
			 i->second->SetBoundingSphere(mesh->ComputeBoundingSphere(i->second->GetFileName()));
			 break;
		 case(4):
			 spriteManager->LoadSprite(dx->ReturnDirectDevice(), i->second->GetFileName());
			 break;
		 }
	 }
}
	
void Engine::CreateLight(GameObject* lightObject)
{
	light->CreateLight(dx->ReturnDirectDevice(), lightObject->GetAmbient(), lightObject->GetDiffuse(), lightObject->GetSpecular(),
		lightObject->GetInverseMass(), lightObject->GetPosition(), lightObject->GetScale(), lightObject->GetName());
}