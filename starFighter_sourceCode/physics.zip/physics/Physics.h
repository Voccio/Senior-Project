#pragma once
#ifndef PHYSICS_H
#define PHYSICS_H
#include<d3dx9.h>
#pragma comment(lib, "d3dx9.lib")
#include"GameObjectClass.h"
#include<vector>
using namespace std;




class ForceGenerator
{
private:

public:
	ForceGenerator();
	~ForceGenerator();
	virtual void UpdateForce(GameObject* object, float dt) = 0;
};

class GravityGenerator : public ForceGenerator
{
private:
	D3DXVECTOR3 gravity;
public:
	GravityGenerator();
	~GravityGenerator();
	void SetGravity(float* grav);
	void UpdateForce(GameObject* object, float dt);
};

class DragGenerator : public ForceGenerator
{
private:
	float dragCoeff1;
	float dragCoeff2;
public:
	DragGenerator();
	~DragGenerator();
	void SetDragCoeff(float coeff1, float coeff2);
	void UpdateForce(GameObject* object, float dt);
};

class TorqueGenerator
{
private:
	D3DXVECTOR3 torque;
public:
	TorqueGenerator();
	~TorqueGenerator();
	void SetTorque(float* torq);
	void UpdateForce(GameObject* object, float dt);
};

struct ForceRegistration
{
	GameObject*			object;
	ForceGenerator*		fg;
};

class ForceRegistry
{
private:
	typedef vector<ForceRegistration> Registry;
	Registry registrations;
public:
	void Add(GameObject* object, ForceGenerator* fg);
	void Remove(GameObject* object, ForceGenerator* fg);
	void Clear();
	void UpdateForces(float dt);
};

class Spring : public ForceGenerator
{
private:
	GameObject* other;
	float springConst;
	float restLength;
	D3DXVECTOR3 point1;
	D3DXVECTOR3 point2;
public:
	Spring();
	~Spring();
	Spring(GameObject* object, float SpringConstant, float springRest, float* pt1, float* pt2);
	void UpdateForce(GameObject* object, float dt);
	void SetSpring(GameObject* object, float SpringConstant, float springRest, float* pt1, float* pt2);
};

class AnchoredSpring : public ForceGenerator
{
private:
	D3DXVECTOR3* anchor;
	float springConst;
	float restLength;
public:
	AnchoredSpring();
	~AnchoredSpring();
	AnchoredSpring(D3DXVECTOR3* anchorEnd, float springConstant, float springRest);
	void UpdateForce(GameObject* object, float dt);
};

class Contact
{
private:
	GameObject* contactObjects[2];
	float restitution;
	D3DXVECTOR3 contactNormal;
	float penetration;
public:
	void Resolve(float dt);
	float CalcSeperatingVel() const;
	void ResolveImpulses(float dt);
	void ResolveInterpenetration(float dt);
	float GetPenetration();
	void AddContactedObjects(GameObject* contactedObjects[2]);
	void SetContactNormal(D3DXVECTOR3 contactNorm);
	void SetPenetration(float value);
	void SetRestitution(float value);
	void Awaken();
};

class ContactGenerator
{
private:

public:
	ContactGenerator();
	~ContactGenerator();
	virtual unsigned int AddContact(Contact* contact, unsigned int limit) const = 0;
};

class Link : public ContactGenerator
{
private:
	GameObject* linkedObjects[2];
public:
	Link();
	~Link();
	float GetCableLength();
	unsigned int AddContact(Contact* contact, unsigned int limit);
	GameObject** GetObjects();
};

class Cable : public Link
{
private:
	float cableLength;
	float restitution;
public:
	Cable();
	~Cable();
	unsigned int AddContact(Contact* contact, unsigned int limit);
};

class Rod : public Link
{
private:
	float rodLength;
public:
	Rod();
	~Rod();
	unsigned int AddContact(Contact* contact, unsigned int limit);
};

class ContactResolver
{
private:
	unsigned int iterations;
	unsigned int iterationsUsed;
public:
	ContactResolver();
	ContactResolver(unsigned int iter);
	void SetIterations(unsigned int num);
	void ResolveContacts(Contact* contactArray, unsigned int numContacts, float dt);
};

struct PotentialContact
{
	GameObject* object[2];
};

template<class BoundingVolume>
class BoundingNode
{
private:
	BoundingNode* children[2];
	BoundingVolume		volume;
	GameObject*			object;
public:
	BoundingNode();
	BoundingNode(BoundingNode* child1, BoundingNode* child2);
	BoundingNode(GameObject* item, BoundingSphere* area, BoundingNode* child1, BoundingNode* child2);
	bool IsLeaf();
	unsigned int GetPotentialContacts(PotentialContact* contacts, unsigned int limit);
	bool Overlaps(BoundingNode<BoundingVolume>* other);
	BoundingVolume* GetVolume();
	unsigned int GetPotentialContactsWith(BoundingNode<BoundingVolume>* other, PotentialContact* contacts, unsigned int limit);
	GameObject* GetGameObject();
	void Insert(GameObject* item, BoundingSphere* area);
	unsigned int GetGrowth();
	unsigned int GetSize();
	BoundingNode* GetChild1();
	BoundingNode* GetChild2();
};

class PhysicsClass
{
private:

public:
	PhysicsClass();
	~PhysicsClass();
	void Update(GameObject* self, float dt);
	void ClearAccum(GameObject* self);
};
#endif //PHYSICS_H