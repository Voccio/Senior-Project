#include"Physics.h"



ForceGenerator::ForceGenerator()
{

}
	
ForceGenerator::~ForceGenerator()
{

}

void ForceGenerator::UpdateForce(GameObject* object, float dt)
{
	
}

GravityGenerator::GravityGenerator()
{
	gravity.x = 0;
	gravity.y = 1;
	gravity.z = 2;
}
	
GravityGenerator::~GravityGenerator()
{

}
	
void GravityGenerator::SetGravity(float* grav)
{
	gravity.x = grav[0];
	gravity.y = grav[1];
	gravity.z = grav[2];
}
	
void GravityGenerator::UpdateForce(GameObject* object, float dt)
{
	object->AddForces(gravity * pow(object->GetInverseMass(), -1));//the pow function call here may be wrong
}

DragGenerator::DragGenerator()
{
	dragCoeff1 = 0.0;
	dragCoeff2 = 0.0f;
}
	
DragGenerator::~DragGenerator()
{

}
	
void DragGenerator::SetDragCoeff(float coeff1, float coeff2)
{
	dragCoeff1 = coeff1;
	dragCoeff2 = coeff2;
}
	
void DragGenerator::UpdateForce(GameObject* object, float dt)
{
	D3DXVECTOR3 force = object->GetVelocity();
	float dragCoeff = D3DXVec3LengthSq(&force);
	dragCoeff = dragCoeff1 * dragCoeff + dragCoeff2 * dragCoeff * dragCoeff;
	D3DXVec3Normalize(&force, &force);
	force *= -dragCoeff;
	object->AddForces(force);
}

TorqueGenerator::TorqueGenerator()
{

}
	
TorqueGenerator::~TorqueGenerator()
{

}
	
void TorqueGenerator::UpdateForce(GameObject* object, float dt)
{
	object->SetTorque(torque);
}

void TorqueGenerator::SetTorque(float* torq)
{
	torque.x = torq[0];
	torque.y = torq[1];
	torque.z = torq[2];
}

void ForceRegistry::Add(GameObject* object, ForceGenerator* fg)
{
	ForceRegistration temp;
	temp.fg = fg;
	temp.object = object;
	registrations.push_back(temp);
}
	
void ForceRegistry::Remove(GameObject* object, ForceGenerator* fg)//not to sure that I did the erasing of the registrations correctly
{
	for(Registry::iterator i = registrations.begin(); i != registrations.end(); i++)
	{
		if(i->fg == fg && i->object == object)
		{
			registrations.erase(i);
		}
	}
}

void ForceRegistry::Clear()
{
	registrations.clear();
}
	
void ForceRegistry::UpdateForces(float dt)
{
	for(Registry::iterator i = registrations.begin(); i != registrations.end(); i++)
	{
		i->fg->UpdateForce(i->object, dt);
	}
}

Spring::Spring()
{

}
	
Spring::~Spring()
{

}
	
Spring::Spring(GameObject* object, float springConstant, float springRest, float* pt1, float* pt2)
{
	other = object;
	springConst = springConstant;
	restLength = springRest;
	point1.x = pt1[0];
	point1.y = pt1[1];
	point1.z = pt1[2];
	point1.x = pt2[0];
	point1.y = pt2[1];
	point1.z = pt2[2];
}
	
void Spring::UpdateForce(GameObject* object, float dt)
{
	D3DXVECTOR3 ptWS1;//this is for the object GameObject
	D3DXVECTOR3 ptWS2;//this is for the other GameObject
	//need a function to convert ptWS1 & ptWS2 into world coordinates
	D3DXVECTOR3 force = ptWS1 - ptWS2;
	force -= object->GetPosition();
	float magnitude = D3DXVec3LengthSq(&force);
	magnitude = abs(magnitude - restLength);
	magnitude *= springConst;
	float temp = D3DXVec3LengthSq(&force);
	force /= temp;
	force *= -magnitude;
	object->AddForceAtPoint(force, ptWS1);
}

void Spring::SetSpring(GameObject* object, float springConstant, float springRest, float* pt1, float* pt2)
{
	other = object;
	springConst = springConstant;
	restLength = springRest;
	point1.x = pt1[0];
	point1.y = pt1[1];
	point1.z = pt1[2];
	point1.x = pt2[0];
	point1.y = pt2[1];
	point1.z = pt2[2];
}

AnchoredSpring::AnchoredSpring()
{

}
	
AnchoredSpring::~AnchoredSpring()
{

}
	
AnchoredSpring::AnchoredSpring(D3DXVECTOR3* anchorEnd, float springConstant, float springRest)
{
	anchor = anchorEnd;
	springConst = springConstant;
	restLength = springRest;
}
	
void AnchoredSpring::UpdateForce(GameObject* object, float dt)
{
	D3DXVECTOR3 force = object->GetPosition();
	force -= *anchor;
	float magnitude = D3DXVec3Length(&force);
	magnitude = (restLength - magnitude) * springConst;
	float temp = D3DXVec3LengthSq(&force);
	force /= temp;
	force *= magnitude;
	object->AddForces(force);
}

void Contact::Resolve(float dt)
{
	ResolveImpulses(dt);
	ResolveInterpenetration(dt);
}
	
float Contact::CalcSeperatingVel() const
{
	D3DXVECTOR3 relativeVel = contactObjects[0]->GetVelocity();
	if(contactObjects[1])
	{
		relativeVel -= contactObjects[1]->GetVelocity();
		return D3DXVec3Dot(&relativeVel, &contactNormal);
	}
	return 0.0f;
}
	
void Contact::ResolveImpulses(float dt)
{
	float sepVel = CalcSeperatingVel();
	if(sepVel > 0)
	{
		return;
	}
	float newSepVel = -sepVel * restitution;
	float deltaVel = newSepVel - sepVel;
	D3DXVECTOR3 accVel = contactObjects[0]->GetAcceleration();
	if(contactObjects[1])
	{
		accVel -= contactObjects[1]->GetAcceleration();
	}
	float accCausedSepVel = D3DXVec3Dot(&accVel, &contactNormal) * dt;
	if(accCausedSepVel < 0.0f)
	{
		newSepVel += restitution * accCausedSepVel;
		if(newSepVel < 0)
			newSepVel = 0.0f;
	}
	float totalInverseMass = contactObjects[0]->GetInverseMass();
	if(contactObjects[1])
	{
		totalInverseMass += contactObjects[1]->GetInverseMass();
	}
	if(totalInverseMass <= 0.0f)
		return;
	float impulse = deltaVel / totalInverseMass;
	D3DXVECTOR3 impulsePerIMass = contactNormal * impulse;
	Awaken();
	contactObjects[0]->SetVelocity(contactObjects[0]->GetVelocity() + impulsePerIMass
		* contactObjects[0]->GetInverseMass());
	if(contactObjects[1])
	{
		contactObjects[1]->SetVelocity(contactObjects[1]->GetVelocity() + impulsePerIMass
		* -contactObjects[1]->GetInverseMass());
	}
}

void Contact::ResolveInterpenetration(float dt)//all function calls to velocity of the gameobjects may be wrong. Book should a movement variable without detailed information so I am using velocity as the movement variable, need to test
{
	if(penetration <= 0.0f)
		return;
	float totalInverseMass = contactObjects[0]->GetInverseMass();
	if(contactObjects[1])
		totalInverseMass += contactObjects[1]->GetInverseMass();
	if(totalInverseMass <= 0.0)
		return;
	D3DXVECTOR3 movePerIMass = contactNormal * (penetration / totalInverseMass);
	Awaken();
	contactObjects[0]->SetVelocity(movePerIMass * contactObjects[0]->GetInverseMass());
	contactObjects[0]->SetPosition(contactObjects[0]->GetPosition()
		+ contactObjects[0]->GetVelocity());
	if(contactObjects[1])
	{
		contactObjects[1]->SetPosition(contactObjects[1]->GetPosition()
		+ contactObjects[1]->GetVelocity());
	}
}

float Contact::GetPenetration()
{
	return penetration;
}

void Contact::AddContactedObjects(GameObject* contactedObjects[2])
{
	contactObjects[0] = contactedObjects[0];
	contactObjects[1] = contactedObjects[1];
}

void Contact::SetContactNormal(D3DXVECTOR3 contactNorm)
{
	contactNormal = contactNorm;
}
	
void Contact::SetPenetration(float value)
{
	penetration = value;
}
	
void Contact::SetRestitution(float value)
{
	restitution = value;
}

void Contact::Awaken()
{
	if(!contactObjects[1])
		return;
	if(contactObjects[0]->GetIsAwake() ^ contactObjects[1]->GetIsAwake())
	{
		if(contactObjects[0]->GetIsAwake())
			contactObjects[0]->SetIsAwake(true);
		else
			contactObjects[1]->SetIsAwake(true);
	}
}

ContactGenerator::ContactGenerator()
{

}

ContactGenerator::~ContactGenerator()
{

}

Link::Link()
{
	linkedObjects[0] = NULL;
	linkedObjects[1] = NULL;
}

Link::~Link()
{

}

float Link::GetCableLength()
{
	D3DXVECTOR3 relativePos = linkedObjects[0]->GetPosition() - linkedObjects[1]->GetPosition();
	return D3DXVec3LengthSq(&relativePos);
}

GameObject** Link::GetObjects()
{
	return linkedObjects;
}

unsigned int Cable::AddContact(Contact* contact, unsigned int limit)
{
	float length = Link::GetCableLength();
	if(length < cableLength)
		return 0;
	GameObject** temp = GetObjects();
	contact->AddContactedObjects(temp);
	D3DXVECTOR3 normal = temp[1]->GetPosition() - temp[0]->GetPosition();
	D3DXVec3Normalize(&normal, &normal);
	contact->SetContactNormal(normal);
	contact->SetPenetration(length - cableLength);
	contact->SetRestitution(restitution);
	return 1;
}

Rod::Rod()
{

}
	
Rod::~Rod()
{

}
	
unsigned int Rod::AddContact(Contact* contact, unsigned int limit)
{
	float currLength = GetCableLength();
	if(currLength == rodLength)
		return 0;
	GameObject** temp = GetObjects();
	contact->AddContactedObjects(temp);
	D3DXVECTOR3 normal = temp[1]->GetPosition() - temp[0]->GetPosition();
	D3DXVec3Normalize(&normal, &normal);
	if(currLength > rodLength)
	{
		contact->SetContactNormal(normal);
		contact->SetPenetration(currLength - rodLength);
	}
	else
	{
		contact->SetContactNormal(normal * -1);
		contact->SetPenetration(rodLength - currLength);
	}
	contact->SetRestitution(0.0f);
	return 1;
}

ContactResolver::ContactResolver()
{
	iterations = 0;
	iterationsUsed = 0;
}
	
ContactResolver::ContactResolver(unsigned int iter)
{
	iterations = iter;
	iterationsUsed = 0;
}
	
void ContactResolver::SetIterations(unsigned int num)
{
	iterations = num;
}
	
void ContactResolver::ResolveContacts(Contact* contactArray, unsigned int numContacts, float dt)
{
	unsigned int i;
	while(iterationsUsed < iterations)
	{
		double max = DBL_MAX;
		unsigned int maxIndex = numContacts;
		for(i = 0; i < numContacts; i++)
		{
			float sepVel = contactArray[i].CalcSeperatingVel();
			if(sepVel < max && (sepVel < 0 || contactArray[i].GetPenetration() > 0))
			{
				max = sepVel;
				maxIndex = i;
			}
		}
		if(maxIndex == numContacts)
			break;
		contactArray[maxIndex].Resolve(dt);
		iterationsUsed++;
	}
}

template<class BoundingVolume>
BoundingNode<BoundingVolume>::BoundingNode()
{
	object = NULL;
	children[0] = NULL;
	children[1] = NULL;
	volume = NULL;
}

template<class BoundingVolume>
BoundingNode<BoundingVolume>::BoundingNode(BoundingNode* child1, BoundingNode* child2)
{
	volume = new BoundingSphere;
	object = new GameObject;
	children[0] = child1;
	children[1] = child2;
}

template<class BoundingVolume>
BoundingNode<BoundingVolume>::BoundingNode(GameObject* item, BoundingSphere* area, BoundingNode* child1, BoundingNode* child2)
{
	object = item;
	volume = area;
	children[0] = child1;
	children[1] = child2;
}

template<class BoundingVolume>
bool BoundingNode<BoundingVolume>::IsLeaf()
{
	return object != NULL;
}

template<class BoundingVolume>
unsigned int BoundingNode<BoundingVolume>::GetPotentialContacts(PotentialContact* contacts, unsigned int limit)
{
	if(IsLeaf() || limit == 0)
		return 0;
	return children[0]->GetPotentialContactsWith(children[1], contacts, limit);
}

template<class BoundingVolume>
bool BoundingNode<BoundingVolume>::Overlaps(BoundingNode<BoundingVolume>* other)
{
	return volume->Overlaps(other->GetVolume());
}

template<class BoundingVolume>
BoundingVolume* BoundingNode<BoundingVolume>::GetVolume()
{
	return volume;
}

template<class BoundingVolume>
unsigned int BoundingNode<BoundingVolume>::GetPotentialContactsWith(BoundingNode<BoundingVolume>* other, PotentialContact* contacts, unsigned int limit)
{
	if(!Overlaps(other) || limit == 0)
		return 0;
	if(IsLeaf() && other->IsLeaf())
	{
		contacts->object[0] = object;
		contacts->object[1] = other->GetGameObject();
		return 1;
	}
	if(other->IsLeaf() || (!IsLeaf() && GetSize() >= other->GetSize()))
	{
		unsigned int count = children[0]->GetPotentialContactsWith(other, contacts, limit);
		if(limit > count)
		{
			return count + children[1]->GetPotentialContactsWith(other, contacts + count, limit - count);
		}
		else
		{
			return count;
		}
	}
	else
	{
		count = GetPotentialContactsWith(other->children[0], contacts, limit);
		if(limit > count)
		{
			return count + GetPotentialContactsWith(other->children[1], contacts + count, limit - count);
		}
		else
		{
			return count;
		}	
	}
}

template<class BoundingVolume>
GameObject* BoundingNode<BoundingVolume>::GetGameObject()
{
	return object;
}

template<class BoundingVolume>
void BoundingNode<BoundingVolume>::Insert(GameObject* item, BoundingSphere* area)
{
	if(IsLeaf())
	{
		children[0] = new BoundingNode(item, area, GetChild1(), GetChild2());
		children[1] = new BoundingNode(GetChild1(), GetChild2());
		this->object = NULL;
		//RecalculateBoundingVolume
	}
	else
	{
		if(children[0]->GetGrowth() < children[1]->GetGrowth())
		{
			children[0]->Insert(item, area);
		}
		else
		{
			children[1]->Insert(item, area);
		}
	}
}

template<class BoundingVolume>
unsigned int BoundingNode<BoundingVolume>::GetGrowth()
{
	return 0;//not a finished function does nothing
}

template<class BoundingVolume>
unsigned int BoundingNode<BoundingVolume>::GetSize()
{
	return 0;//not a finished function does nothing
}

template<class BoundingVolume>
BoundingNode<BoundingVolume>* BoundingNode<BoundingVolume>::GetChild1()
{
	return children[0];
}

template<class BoundingVolume>
BoundingNode<BoundingVolume>* BoundingNode<BoundingVolume>::GetChild2()
{
	return children[1];
}

PhysicsClass::PhysicsClass()
{

}

PhysicsClass::~PhysicsClass()
{

}

void PhysicsClass::Update(GameObject* self, float dt)
{
	if(!self->GetIsAwake())
		return;
	if(self->GetInverseMass() <= 0.0f)
		return;
	D3DXVECTOR3 lastAccel = self->GetAcceleration();
	lastAccel += self->GetForces() * self->GetInverseMass();
	lastAccel *= dt;
	self->SetAcceleration(lastAccel);
	self->SetVelocity(self->GetVelocity() += lastAccel);
	self->SetVelocity(lastAccel);
	D3DXVECTOR3 velocity = self->GetVelocity();
	if (sqrt((velocity.x * velocity.x) + (velocity.y * velocity.y) + (velocity.z * velocity.z)) > 200 )
	{
		D3DXVec3Normalize(&velocity, &velocity);
		velocity *= 200;
		self->SetVelocity(velocity);
	}
	self->SetPosition(self->GetPosition() += self->GetVelocity() * dt);

	D3DXVECTOR3 lastAngular = self->GetRotation();
	lastAngular += self->GetTorques() * self->GetInverseMass();
	lastAngular *= dt;
	self->SetRotation(lastAngular);
	lastAngular *= dt;
	D3DXQUATERNION temp(lastAngular.y, lastAngular.x, lastAngular.z, 0);
	D3DXQUATERNION ori = self->GetOrientation();
	D3DXQuaternionMultiply(&temp, &temp, &ori);
	ori += temp * 0.5f;
	self->SetOrientation(ori);
	ClearAccum(self);
}

void PhysicsClass::ClearAccum(GameObject* self)
{
	self->ClearForces();
	self->ClearTorque();
}