#include"Path.h"



PathClass::PathClass()
{

}
	
PathClass::~PathClass()
{
	Shutdown();
}
	
void PathClass::UpdatePath()
{

}

void PathClass::CreatePath(D3DXVECTOR3* pathPoints)
{
	Path temp;
	PathNode tempPoint;
	temp.pathNodes.clear();
	for(int i = 0; i < sizeof(pathPoints); i++)
	{
		tempPoint.node = pathPoints[i];
		temp.pathNodes.push_back(tempPoint);
	}
	paths.push_back(temp);
}
	
GameObject* PathClass::GetNextNode(GameObject *self)
{
	
	D3DXVECTOR3 distance;
	float check;
	float close = 0.0;
	for(unsigned int i = 0; i < paths[self->GetPathing()].pathNodes.size(); i++)
	{
		distance = self->GetPosition() - paths[self->GetPathing()].pathNodes[i].node;
		check = abs(D3DXVec3Length(&distance));
		if(close != 0.0 && check < close)
		{
			close = check;
		}
		else if(close == 0.0)
		{
			close = check;
		}
		else if(close != 0.0 && check > close)
		{
			GameObject* temp;
			temp = new GameObject;
			temp->SetPosition(paths[self->GetPathing()].pathNodes[i].node);
			return temp;
		}
	}
	return NULL;
}

void PathClass::Shutdown()
{
	paths.empty();
}