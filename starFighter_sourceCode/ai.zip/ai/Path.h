#pragma once
#ifndef PATH_H
#define PATH_H
#include <d3dx9.h>
#pragma comment(lib, "d3dx9.lib")
#include<vector>
#include"Physics.h"
using namespace std;


struct PathNode
{
	D3DXVECTOR3 node;
};

struct Path
{
	vector<PathNode> pathNodes;
};

class PathClass
{
private:
	vector<Path> paths;
public:
	PathClass();
	~PathClass();
	void UpdatePath();//add float dt when using non kinematic movement
	void CreatePath(D3DXVECTOR3* pathPoints);
	GameObject* GetNextNode(GameObject* self);
	void Shutdown();
};
#endif