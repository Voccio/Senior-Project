#include "Engine.h"
using namespace std;

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow)
{
	Engine engine = Engine();
	engine.Run(hInstance);
	return 0;
}