#pragma once
#include"Scene.h"
#include"Steering.h"
#include "Input.h"
#include "Camera.h"
#include"GameScene.h"
#include "MenuScene.h"





class GameLogicClass
{
private:
	Steering		steeringControl;
	PhysicsClass	physics;
	ForceRegistry	forceRegistry;
	DragGenerator	dragGenerator;
	InputClass*		input;
	CameraClass*	camera;
	Scene*			scene;

	double			timer;
	double			trigger;
public:
	GameLogicClass();
	~GameLogicClass();
	void Startup(HWND hWnd, HINSTANCE hInstance);
	void Update(Scene* currScene, float dt);
	void Shutdown();
	Scene* GetScene();
	void InitAi();
	CameraClass* GetCamera();
	void CreateCamera(HWND hWnd);
};