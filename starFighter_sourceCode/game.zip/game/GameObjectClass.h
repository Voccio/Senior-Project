#pragma once
#ifndef GAMEOBJECTCLASS_H
#define GAMEOBJECTCLASS_H
#include <string>
#include <list>
#include <map>
#include<Windows.h>
#include<d3dx9.h>
#pragma comment(lib, "d3dx9.lib")



const float EPSILON  = 0.001f;
const float INFINITY = FLT_MAX;



enum ObjectType
{
	 audioType, effectsType, fontType, meshType, spriteType
};

enum GameType
{
	noUpdate, AI1, AI2, player, nonStaticEnviron, weaponFire
};

struct BoundingSphere 
{
	BoundingSphere()
		: pos(0.0f, 0.0f, 0.0f), radius(0.0f){}

	D3DXVECTOR3 pos;
	float radius;
};

struct AABB 
{
	// Initialize to an infinitely small bounding box.
	AABB()
		: minPt(INFINITY, INFINITY, INFINITY),
		  maxPt(-INFINITY, -INFINITY, -INFINITY){}

    D3DXVECTOR3 center()const
	{
		return (minPt+maxPt)*0.5f;
	}

	D3DXVECTOR3 extent()const
	{
		return (maxPt-minPt)*0.5f;
	}

	void xform(const D3DXMATRIX& M, AABB& out)
	{
		// Convert to center/extent representation.
		D3DXVECTOR3 c = center();
		D3DXVECTOR3 e = extent();

		// Transform center in usual way.
		D3DXVec3TransformCoord(&c, &c, &M);

		// Transform extent.
		D3DXMATRIX absM;
		D3DXMatrixIdentity(&absM);
		absM(0,0) = fabsf(M(0,0)); absM(0,1) = fabsf(M(0,1)); absM(0,2) = fabsf(M(0,2));
		absM(1,0) = fabsf(M(1,0)); absM(1,1) = fabsf(M(1,1)); absM(1,2) = fabsf(M(1,2));
		absM(2,0) = fabsf(M(2,0)); absM(2,1) = fabsf(M(2,1)); absM(2,2) = fabsf(M(2,2));
		D3DXVec3TransformNormal(&e, &e, &absM);

		// Convert back to AABB representation.
		out.minPt = c - e;
		out.maxPt = c + e;
	}

	D3DXVECTOR3 minPt;
	D3DXVECTOR3 maxPt;
};

class GameObject
{
private:
	//Game Logic data
	GameType type;
	std::string name;
	char* sound;
	LPCWSTR fileName;						//use for type of font, i.e "New Times Roman"
	ObjectType assetType;
	//Physics data
	D3DXVECTOR3		position;				//use [0] for font ht, use [1] for font width
	D3DXVECTOR3		scale;					//use for direction for light, use for target for camera
	D3DXVECTOR3		rotation;
	D3DXQUATERNION	orientation;
	D3DXVECTOR3		velocity;
	D3DXVECTOR3		acceleration;
	D3DXVECTOR3		facing;

	float			inverseMass;			//use for range for light
	D3DXMATRIX		transformMat;
	//D3DXMATRIX		inverseInertiaTensor;//not needed for a space game and also not completed to use the inertia tensor
	D3DXVECTOR3		forceAccum;
	D3DXVECTOR3		torqueAccum;
	float			motion;
	bool			isAwake;				//is used in scene to load visible assets to a render list && used in physics to know if to update or ignore AI object that are sleeping
	bool			canSleep;				//use for font italic && use for if a sound is playing
	BoundingSphere	boundingSphere;
	AABB			boundingBox;
	//light object data, also used for what is specified for the objects specified below
	float ambient[4];						//use for up for camera
	float diffuse[4];						//use for color for sprites && use for color of font
	float specular[4];
	//Pathing data
	int pathing;
	float hitPoints;						//Integer storing hitpoints

public:
	GameObject();
	~GameObject();
	GameType GetType ();
	void SetType (GameType gameType);
	std::string GetName ();
	void SetName (std::string value);
	LPCWSTR GetFileName();
	void SetFileName(LPCWSTR name);
	void SetPosition(float* pos);
	D3DXVECTOR3 GetPosition();
	void SetScale(float* scl);
	D3DXVECTOR3 GetScale();
	void SetRotation(float* rot);
	D3DXVECTOR3 GetRotation();
	void SetOrientation(float* ori);
	D3DXQUATERNION GetOrientation();
	void SetAmbient(float* amb);
	float* GetAmbient();
	void SetDiffuse(float* dif);
	float* GetDiffuse();
	void SetSpecular(float* spec);
	float* GetSpecular();
	void SetSound(char* name);
	char* GetSoundName();
	void SetVelocity(float* vel);
	D3DXVECTOR3 GetVelocity();
	void SetAssetType(ObjectType objectType);
	ObjectType ReturnAssetType();
	void SetPathing(int num);
	int GetPathing();
	void SetInverseMass(float mass);
	float GetInverseMass();
	void SetAcceleration(float* accel);
	D3DXVECTOR3 GetAcceleration();
	//void SetInertiaTensor(D3DXMATRIX inertiaTensor);
	void ClearForces();
	void AddForces(D3DXVECTOR3 newForce);
	bool GetIsAwake();
	void SetIsAwake(bool value);
	bool GetCanSleep();
	void SetCanSleep(bool value);
	void ShouldSleep();
	void AddTorque(D3DXVECTOR3 torq);
	void ClearTorque();
	void AddForceAtPoint(D3DXVECTOR3 force, D3DXVECTOR3 point);
	void AddForceAtBodyPoint(D3DXVECTOR3 force, D3DXVECTOR3 point);
	D3DXVECTOR3 GetForces();
	D3DXVECTOR3 GetTorques();
	void SetFacing(D3DXVECTOR3 pos);
	D3DXVECTOR3 GetFacing();
	void CalcTransformation();
	D3DXMATRIX	GetTransformation();
	void SetTorque(float* torq);
	void SetAABB(AABB boundBox);
	void SetBoundingSphere(BoundingSphere boundSphere);
	void SetHitPoints(int);
	int GetHitPoints();
};
#endif