#include"GameObjectClass.h"


GameObject::GameObject()
{
	name = "";
	type = noUpdate;
	fileName = L"";
	sound = "";
	assetType = audioType;
	
	position[0] = 0.0f;
	position[1] = 0.0f;
	position[2] = 0.0f;

	scale[0] = 0.0;
	scale[1] = 0.0;
	scale[2] = 0.0;

	rotation[0] = 0.0f;
	rotation[1] = 0.0f;
	rotation[2] = 0.0f;

	orientation[0] = 0.0f;
	orientation[1] = 0.0f;
	orientation[2] = 0.0f;
	orientation[3] = 0.0f;

	ambient[0] = 0.0;
	ambient[1] = 0.0;
	ambient[2] = 0.0;
	ambient[3] = 0.0;

	diffuse[0] = 0.0;
	diffuse[1] = 0.0;
	diffuse[2] = 0.0;
	diffuse[3] = 0.0;

	specular[0] = 0.0;
	specular[1] = 0.0;
	specular[2] = 0.0;
	specular[3] = 0.0;

	velocity[0] = 0.0;
	velocity[1] = 0.0;
	velocity[2] = 0.0;

	inverseMass = 0.0;
	acceleration.x = 0.0;
	acceleration.y = 0.0;
	acceleration.z = 0.0;
	motion = 0.0f;
	torqueAccum.x = 0.0f;
	torqueAccum.y = 0.0f;
	torqueAccum.z = 0.0f;
	forceAccum.x = 0.0f;
	forceAccum.y = 0.0f;
	forceAccum.z = 0.0f;
	facing.x = 0.0f;
	facing.y = 0.0f;
	facing.z = 0.0f;

	pathing = -1;
	isAwake = true;
	canSleep = true;
	hitPoints = 100;
}

GameObject::~GameObject()
{

}

void GameObject::SetPosition(float* pos)
{
	position[0] = pos[0];
	position[1] = pos[1];
	position[2] = pos[2];
}
	
void GameObject::SetScale(float scl[3])
{
	scale[0] = scl[0];
	scale[1] = scl[1];
	scale[2] = scl[2];
}
	
void GameObject::SetRotation(float* rot)
{
	rotation[0] = rot[0];
	rotation[1] = rot[1];
	rotation[2] = rot[2];
}
	
void GameObject::SetOrientation(float* ori)
{
	orientation[0] = ori[0];
	orientation[1] = ori[1];
	orientation[2] = ori[2];
	orientation[3] = ori[3];
}

void GameObject::SetAmbient(float amb[4])
{
	ambient[0] = amb[0];
	ambient[1] = amb[1];
	ambient[2] = amb[2];
	ambient[3] = amb[3];
}
	
void GameObject::SetDiffuse(float dif[4])
{
	diffuse[0] = dif[0];
	diffuse[1] = dif[1];
	diffuse[2] = dif[2];
	diffuse[3] = dif[3];
}
	
void GameObject::SetSpecular(float spec[4])
{
	specular[0] = spec[0];
	specular[1] = spec[1];
	specular[2] = spec[2];
	specular[3] = spec[3];
}

GameType GameObject::GetType () { return type; }
void GameObject::SetType (GameType value) { type = value; }

std::string GameObject::GetName () { return name; }
void GameObject::SetName (std::string value) { name = value; }

LPCWSTR GameObject::GetFileName(){return fileName;}
void GameObject::SetFileName(LPCWSTR name){fileName = name;}

D3DXVECTOR3 GameObject::GetPosition () { return position; }

D3DXVECTOR3 GameObject::GetScale () { return scale; }

D3DXVECTOR3 GameObject::GetRotation () { return rotation; }

D3DXQUATERNION GameObject::GetOrientation()
{
	return orientation;
}

void GameObject::SetAssetType(ObjectType type)
{
	assetType = type;
}
	
ObjectType GameObject::ReturnAssetType()
{
	return assetType;
}

float* GameObject::GetAmbient()
{
	return ambient;
}

float* GameObject::GetDiffuse()
{
	return diffuse;
}

float* GameObject::GetSpecular()
{
	return specular;
}

void GameObject::SetSound(char* name)
{
	sound = name;
}

char* GameObject::GetSoundName()
{
	return sound;
}

void GameObject::SetVelocity(float vel[3])
{
	velocity[0] = vel[0];
	velocity[1] = vel[1];
	velocity[2] = vel[2];
}

D3DXVECTOR3 GameObject::GetVelocity()
{
	return velocity;
}

void GameObject::SetPathing(int num)
{
	pathing = num;
}
	
int GameObject::GetPathing()
{
	return pathing;
}

void GameObject::SetInverseMass(float mass)
{
	inverseMass = 1 / mass;
}
	
float GameObject::GetInverseMass()
{
	return inverseMass;
}

void GameObject::SetAcceleration(float* force)
{
	acceleration.x += force[0];
	acceleration.y += force[1];
	acceleration.z += force[2];
}

D3DXVECTOR3 GameObject::GetAcceleration()
{
	return acceleration;
}

/*//This is for aerodynamics of a flight simulator, not needed in space. 
void GameObject::SetInertiaTensor(D3DXMATRIX inertiaTensor)
{
	float *temp;
	temp[0] = D3DXMatrixDeterminant(&inertiaTensor);
	D3DXMatrixInverse(&inverseInertiaTensor, temp, &inertiaTensor);
}
*/

void GameObject::ClearForces()
{
	forceAccum.x = 0.0f;
	forceAccum.y = 0.0f;
	forceAccum.z = 0.0f;
}

void GameObject::AddForces(D3DXVECTOR3 newForce)
{
	forceAccum += newForce;
	isAwake = true;
}

bool GameObject::GetIsAwake()
{
	return isAwake;
}

void GameObject::SetIsAwake(bool value)
{
	if(value)
	{
		isAwake = true;
		motion = EPSILON * 2.0f;
	}
	else
	{
		float *temp;
		temp = new float;
		temp[0] = 0.0f, temp[1] = 0.0f, temp[2] = 0.0f;
		isAwake = false;
		SetVelocity(temp);
		SetRotation(temp);
	}
}

bool GameObject::GetCanSleep()
{
	return canSleep;
}
	
void GameObject::SetCanSleep(bool value)
{
	canSleep = value;
}

void GameObject::ShouldSleep()
{
	motion = D3DXVec3LengthSq(&velocity) + D3DXVec3LengthSq(&rotation);
	if(motion < EPSILON)
	{
		SetIsAwake(false);
	}
}

void GameObject::AddTorque(D3DXVECTOR3 torq)
{
	torqueAccum += torq;
	isAwake = true;
}
	
void GameObject::ClearTorque()
{
	torqueAccum.x = 0.0f;
	torqueAccum.y = 0.0f;
	torqueAccum.z = 0.0f;
}

void GameObject::AddForceAtPoint(D3DXVECTOR3 force, D3DXVECTOR3 point)
{
	//convert to coordinates relative to center of mass
	D3DXVECTOR3 pt = point;
	pt -= position;
	forceAccum += force;
	torqueAccum.x = pt.y * force.z - pt.z * force.y,
		pt.z * force.x - pt.x * force.z,
		pt.x * force.y - pt.y * force.x;
	isAwake = true;
}

void GameObject::AddForceAtBodyPoint(D3DXVECTOR3 force, D3DXVECTOR3 point)
{
	D3DXVECTOR3 pt;
	AddForceAtPoint(force, pt);
}

D3DXVECTOR3 GameObject::GetForces()
{
	return forceAccum;
}

D3DXVECTOR3 GameObject::GetTorques()
{
	return torqueAccum;
}

void GameObject::SetFacing(D3DXVECTOR3 pos)
{
	facing = pos;
}
	
D3DXVECTOR3 GameObject::GetFacing()
{
	return facing;
}

void GameObject::CalcTransformation()
{
	D3DXMATRIX rotMat;
	D3DXMATRIX scalMat;
	D3DXMATRIX transMat;
	D3DXMatrixIdentity(&transformMat);
	D3DXQUATERNION temp = GetOrientation();
	D3DXQuaternionNormalize(&temp, &temp);
	D3DXMatrixTranslation(&transMat, GetPosition()[0], GetPosition()[1], GetPosition()[2]);
	D3DXMatrixScaling(&scalMat, GetScale()[0], GetScale()[1], GetScale()[2]);
	D3DXMatrixRotationQuaternion(&rotMat, &temp);
	D3DXMatrixMultiply(&scalMat, &scalMat, &rotMat);
	D3DXMatrixMultiply(&transformMat, &scalMat, &transMat);
	
	D3DXMatrixMultiply(&transMat, &rotMat, &transMat);
	facing.x = GetPosition()[0], facing.y = GetPosition()[1], facing.z = GetPosition()[2] - 1.0f;
	D3DXVec3Normalize(&facing, &facing);
	D3DXVec3TransformCoord(&facing, &facing, &transMat);
}

D3DXMATRIX	GameObject::GetTransformation()
{
	return transformMat;
}

void GameObject::SetTorque(float* torq)
{
	torqueAccum += torq;
}

void GameObject::SetAABB(AABB boundBox)
{
	boundingBox = boundBox;
}
	
void GameObject::SetBoundingSphere(BoundingSphere boundSphere)
{
	boundingSphere = boundSphere;
}

void GameObject::SetHitPoints(int num)
{
	hitPoints = num;
}

int GameObject::GetHitPoints()
{
	return hitPoints;
}