#include"GameLogic.h"
#include <iostream>
using namespace std;


GameLogicClass::GameLogicClass()
{
	input = new InputClass();
	camera = new CameraClass();
	timer = 0.0f;
	trigger = 0.0f;
}

GameLogicClass::~GameLogicClass()
{
	
}

void GameLogicClass::Startup(HWND hWnd, HINSTANCE hInstance)
{
	input->InitInput(hWnd, hInstance);
	scene = new MenuScene;
	CreateCamera(hWnd);
	dragGenerator.SetDragCoeff(0.001f, 0.0f); //drags by .1%
	//drag neds to be messed with otherwise the ship can accelerate out of the game zone easily
	//trigger = 15;
}

void GameLogicClass::Shutdown()
{
	input->Shutdown();
}

void GameLogicClass::Update(Scene* currScene, float dt)
{
	if(!currScene->ReturnVideoPlay())
	{
		input->Poll();
		std::list<GameObject*> updateList;
		updateList = currScene->ReturnGameObjects();
		switch(currScene->ReturnGameState())
		{
		case(0):
			timer += dt;
			if(trigger < timer)
			{
				if(!currScene->GetInstance("menuBack"))
				{
					//currScene->Remove(currScene->GetInstance("DiscoveryHit"));
					currScene->Remove(currScene->GetInstance("opening"));
					currScene->Remove(currScene->GetInstance("logo"));
					currScene->Remove(currScene->GetInstance("3dsMaxBanner"));
					currScene->Remove(currScene->GetInstance("3dsMaxLogo"));
					currScene->Remove(currScene->GetInstance("gimpLogo"));
					currScene->Remove(currScene->GetInstance("ParentalAdvisory"));
					currScene->Remove(currScene->GetInstance("RatingExplicit"));

					GameObject* temp;
					temp = new GameObject;
					*temp = *currScene->ReturnAsset("menuBack");
					currScene->Add(temp);
	
					temp = new GameObject;
					*temp = *currScene->ReturnAsset("newGameH");
					currScene->Add(temp);

					temp = new GameObject;
					*temp = *currScene->ReturnAsset("exit");
					currScene->Add(temp);

					currScene->GetInstance("DiscoveryHit")->SetCanSleep(false);
				}
				if(input->KeyDown(DIK_ESCAPE))
					currScene->ChangeGameState(3);
				if(input->KeyDown(DIK_W))
				{
					currScene->Highlight();
				}
				if(input->KeyDown(DIK_S))
				{
					currScene->Highlight();
				}
				if(input->KeyDown(DIK_RETURN))
				{
					if(currScene->GetInstance("newGame"))
					{
						currScene->ChangeGameState(3);
					}
					else
					{
						scene = new GameScene;
						scene->ChangeGameState(1);
					}
				}
			}
			currScene->GetInstance("BlackVortex")->SetCanSleep(true);
			currScene->SetUpdatedObjects(updateList);
			break;
		case(1):
			if(input->KeyDown(DIK_ESCAPE))
			{
				scene = new MenuScene;
				scene->ChangeGameState(0);
			}
			else
			{
				for (std::list<GameObject*>::iterator i = updateList.begin(); i != updateList.end(); ++i)
				{
					if((*i)->GetType() == 0) //noUpdate
					{
						
					}
					else if((*i)->GetType() == 1) //AI1, motherships
					{
						D3DXMATRIX tempRot;
						D3DXVECTOR3 tempPos;
						D3DXMatrixRotationY(&tempRot, .00005f);//adjust number for orbiting speed
						D3DXVec3TransformCoord(&tempPos, &(*i)->GetPosition(), &tempRot);
						(*i)->SetPosition(tempPos);
						(*i)->CalcTransformation();
					}
					else if((*i)->GetType() == 2) //AI2, minion ships
					{
						//(*i)->SetPosition((*i)->GetPosition() += steeringControl.Seek((*i), currScene->GetInstance("player")).linear);
						(*i)->CalcTransformation();
					}
					else if((*i)->GetType() == 3) //player
					{
						if ((*i)->GetHitPoints() == 0)
						{
							(*i)->SetIsAwake(false);
							currScene->Remove((*i));
							timer = 0;
							(*i)->SetHitPoints(100);
							trigger = 5;
						}					
						if ((*i)->GetIsAwake())
						{
							if (currScene->GetInstance("humanMotherShip")->GetHitPoints() <= 0)
							{
								(*i)->SetHitPoints(0);
								currScene->Remove(currScene->ReturnAsset("humanMotherShip"));
								GameObject* temp;
								temp = new GameObject;
								*temp = *currScene->ReturnAsset("humanMotherShip");
								temp->CalcTransformation();
								currScene->Add(temp);
							}
							else if (currScene->GetInstance("alienMotherShip")->GetHitPoints() <= 0)
							{
								scene = new MenuScene;
								scene->ChangeGameState(0);
							}
							
							if(input->MouseButtonDown(0))
							{	
								GameObject* temp;
								temp = new GameObject;
								*temp = *currScene->ReturnAsset("weaponFire");
								temp->SetPosition((*i)->GetFacing());
								temp->CalcTransformation();
								currScene->Add(temp);		
							}
							
							//main thruster
							if(input->KeyDown(DIK_SPACE))
							{
  								D3DXVECTOR3 temp;
								temp = (*i)->GetPosition() - (*i)->GetFacing();
								//temp = (*i)->GetFacing() - (*i)->GetPosition();
								temp *= 100.0f;
								(*i)->AddForces(temp);
							}
							if(input->KeyDown(DIK_A))
							{
								D3DXVECTOR3 temp(-50.0f, 0, 0);
								(*i)->AddTorque(temp);
							}
							if(input->KeyDown(DIK_D))
							{
								D3DXVECTOR3 temp(50.0f, 0, 0);
								(*i)->AddTorque(temp);
							}
							if(input->KeyDown(DIK_W))
							{
								D3DXVECTOR3 temp(0, -50.0f, 0);
								(*i)->AddTorque(temp);
							}
							if(input->KeyDown(DIK_S))
							{
								D3DXVECTOR3 temp(0, 50.0f, 0);
								(*i)->AddTorque(temp);
							}
							if(input->KeyDown(DIK_Q))
							{
								D3DXVECTOR3 temp(0, 0, -50.0f);
								(*i)->AddTorque(temp);
							}
							if(input->KeyDown(DIK_E))
							{
								D3DXVECTOR3 temp(0, 0, 50.0f);
								(*i)->AddTorque(temp);
							}
							if(input->KeyDown(DIK_H))
							{
								(*i)->SetHitPoints(0);
							}
							dragGenerator.UpdateForce((*i), dt);
							physics.Update((*i), dt);
							(*i)->CalcTransformation();
						
							D3DXVECTOR3 camPos;
							camPos = (*i)->GetPosition();
							camPos.y += 1.0f, camPos.z += 8.0f;
							D3DXVECTOR3 camTar = (*i)->GetPosition();
							D3DXVECTOR3 camUp(0, 1, 0);						
							camera->LookAt(camPos, camTar, camUp);
						}
						else 
						{
							timer += dt;
							if (trigger < timer)
							{
								D3DXVECTOR3 playerPos;
								playerPos = currScene->GetInstance("humanMotherShip")->GetPosition();
								playerPos.y -= 20.0;
								GameObject* temp;
								temp = new GameObject;
								*temp = *currScene->ReturnAsset("player");
								temp->SetPosition(playerPos);
								temp->SetIsAwake(true);
								currScene->Add(temp);
							}
						}
					}
					else if((*i)->GetType() == 4) //nonStaticEnviron
					{
						D3DXMATRIX tempRot;
						D3DXVECTOR3 tempPos;
						D3DXMatrixRotationY(&tempRot, .0001f);//adjust number for orbiting speed
						D3DXVec3TransformCoord(&tempPos, &(*i)->GetPosition(), &tempRot);
						(*i)->SetPosition(tempPos);
						(*i)->CalcTransformation();
					}
					else if((*i)->GetType() == 5) //weaponFire
					{
						float temp;

						temp = (*i)->GetHitPoints();
						temp -= dt;
						(*i)->SetHitPoints(temp);
						if((*i)->GetHitPoints() <= 0)
							currScene->Remove((*i));
						else
						{
							if(D3DXVec3Length(&(*i)->GetVelocity()) == 0)
							{
								D3DXVECTOR3 temp;
								temp = currScene->GetInstance("player")->GetPosition() - currScene->GetInstance("player")->GetFacing();
								temp *= 100.0f;
								(*i)->AddForces(temp);
							}
							else
								(*i)->AddForces((*i)->GetVelocity());
						}
						dragGenerator.UpdateForce((*i), dt);
						physics.Update((*i), dt);
						(*i)->CalcTransformation();
					}
				}
				currScene->SetUpdatedObjects(updateList);
			}
			break;
		case(2):
			break;
		}
	}
}

Scene* GameLogicClass::GetScene()
{
	return scene;
}

void GameLogicClass::InitAi()
{
	steeringControl.InitPathing();
}

CameraClass* GameLogicClass::GetCamera()
{
	return camera;
}

void GameLogicClass::CreateCamera(HWND hWnd)
{
	camera->LookAt(camera->ReturnPosition(), camera->ReturnLook(), camera->ReturnUp());
	RECT rect;
	GetWindowRect(hWnd, &rect);
	camera->SetLens(D3DX_PI * 0.25f, (float)rect.right / (float)rect.bottom, 1.0f, 100000.0f);		
}